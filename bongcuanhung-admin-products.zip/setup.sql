-- Thay admin@example.com bằng email quản trị trước khi chạy SQL
create table if not exists public.site_events(id bigint generated always as identity primary key,event_type text not null check(event_type in ('page_view','click')),target text check(target is null or target in ('tiktok','zalo','facebook')),session_id text not null,page_path text,created_at timestamptz not null default now());
create index if not exists site_events_created_at_idx on public.site_events(created_at desc);
create index if not exists site_events_session_idx on public.site_events(session_id);
alter table public.site_events enable row level security;
drop policy if exists "Public can insert analytics events" on public.site_events;
create policy "Public can insert analytics events" on public.site_events for insert to anon,authenticated with check(event_type in ('page_view','click') and (target is null or target in ('tiktok','zalo','facebook')) and length(session_id) between 8 and 100);
drop policy if exists "Only named admin can read analytics" on public.site_events;
create policy "Only named admin can read analytics" on public.site_events for select to authenticated using((auth.jwt()->>'email')='admin@example.com');
grant usage on schema public to anon,authenticated;
grant insert on public.site_events to anon,authenticated;
grant select on public.site_events to authenticated;
grant usage,select on sequence public.site_events_id_seq to anon,authenticated;


-- ===== QUẢN LÝ SẢN PHẨM + HÌNH ẢNH =====
-- Thay admin@example.com ở chính sách đọc sản phẩm bằng email quản trị thực tế.
create table if not exists public.products (
 id bigint generated always as identity primary key,
 name text not null,
 price numeric(12,0) not null default 0 check(price >= 0),
 description text,
 image_url text,
 is_active boolean not null default true,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
alter table public.products enable row level security;

drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products" on public.products
for select to anon, authenticated using (is_active = true);

drop policy if exists "Admin can manage products" on public.products;
create policy "Admin can manage products" on public.products
for all to authenticated
using ((auth.jwt()->>'email') = 'admin@example.com')
with check ((auth.jwt()->>'email') = 'admin@example.com');

grant select on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;
grant usage, select on sequence public.products_id_seq to authenticated;

-- Bucket ảnh sản phẩm: ảnh công khai để website hiển thị, chỉ admin được tải lên/xóa.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images','product-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=true, file_size_limit=5242880, allowed_mime_types=array['image/jpeg','image/png','image/webp'];

drop policy if exists "Public can view product images" on storage.objects;
create policy "Public can view product images" on storage.objects
for select to public using (bucket_id='product-images');

drop policy if exists "Admin can upload product images" on storage.objects;
create policy "Admin can upload product images" on storage.objects
for insert to authenticated with check (bucket_id='product-images' and (auth.jwt()->>'email')='admin@example.com');

drop policy if exists "Admin can update product images" on storage.objects;
create policy "Admin can update product images" on storage.objects
for update to authenticated using (bucket_id='product-images' and (auth.jwt()->>'email')='admin@example.com')
with check (bucket_id='product-images' and (auth.jwt()->>'email')='admin@example.com');

drop policy if exists "Admin can delete product images" on storage.objects;
create policy "Admin can delete product images" on storage.objects
for delete to authenticated using (bucket_id='product-images' and (auth.jwt()->>'email')='admin@example.com');
