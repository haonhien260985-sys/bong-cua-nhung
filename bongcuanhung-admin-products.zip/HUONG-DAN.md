# Cài trang quản trị bongcuanhung.shop

## Bộ file
- admin.html: trang đăng nhập và dashboard.
- tracking.js: ghi nhận lượt xem và lượt nhấn TikTok/Zalo/Facebook.
- setup.sql: tạo bảng dữ liệu và phân quyền.

## 1. Tạo Supabase
1. Tạo project tại https://supabase.com/
2. Project Settings → API: sao chép Project URL và anon/public key.
3. Trong setup.sql, thay admin@example.com bằng email quản trị bạn muốn dùng.
4. SQL Editor: dán SQL đã sửa và Run.
5. Authentication → Users → Add user: tạo đúng email trên và mật khẩu. Tắt public sign-ups.

## 2. Điền thông tin kết nối
Trong admin.html và tracking.js, thay PASTE_SUPABASE_URL và PASTE_SUPABASE_ANON_KEY bằng Project URL và anon/public key. Tuyệt đối không dùng service_role key.

## 3. Đưa lên GitHub Pages
Repo: https://github.com/haonhien260985-sys/bong-cua-nhung
1. Upload admin.html và tracking.js vào thư mục gốc, cùng cấp với index.html.
2. Trong index.html, thêm dòng này ngay trước </body>:
   <script src="tracking.js" defer></script>
3. Commit thay đổi, chờ GitHub Pages cập nhật.
4. Mở https://bongcuanhung.shop/admin.html và đăng nhập.

## 4. Lưu ý
Dữ liệu chỉ bắt đầu sau khi cài tracking; không có lịch sử cũ. Số khách là số phiên trình duyệt ước tính. Dashboard Basic không tự đọc đơn hàng/doanh thu TikTok Shop. Khách chỉ được ghi sự kiện; chỉ email quản trị khai báo trong SQL được đọc thống kê.


## 5. Quản lý sản phẩm và ảnh
- Chạy phần SQL bổ sung trong `setup.sql` sau khi thay `admin@example.com` bằng đúng email quản trị.
- Trong trang `/admin.html`, mục **Quản lý sản phẩm** cho phép thêm tên, giá, mô tả và tải ảnh lên (tối đa 5MB, JPG/PNG/WEBP), sửa hoặc xóa sản phẩm.
- Ảnh được lưu trong Supabase Storage bucket `product-images`.
- Lưu ý: danh sách trong trang quản trị đã được lưu vào Supabase. Để sản phẩm tự xuất hiện trên trang cửa hàng, phần hiển thị sản phẩm của `index.html` cũng cần được kết nối để đọc bảng `products`; chức năng đó chưa tự thay đổi giao diện cửa hàng hiện tại.
